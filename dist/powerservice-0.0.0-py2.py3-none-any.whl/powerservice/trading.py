"""
Module that contains the get trades functionality. This module will generate a random set of dummy positions.
"""
import random
import logging
import datetime
import uuid

import numpy as np
import pandas as pd

from pyspark.sql import SparkSession
from pyspark.sql.dataframe import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType


def check_if_valid_date(date: str):
    """
    Verify that the date format matches d/m/y
    :param date: str date in d/m/y format
    :return: True or False
    """
    date_format = "%d/%m/%Y"

    """ Warning to any non python devs reading this code..
        In Python the only way to test a valid date is with a try catch. Yep, it sux.
    """
    if not isinstance(date, str):
        return False

    try:
        datetime.datetime.strptime(date, date_format)
        valid_date = True
    except ValueError:
        valid_date = False

    return valid_date


def random_nan(x):
    """
    Replace x with a nan, if the random number == 1
    """
    if random.randrange(0, 15) == 1:
        x = np.nan

    return x


def generate_new_random_trade_position(date: str):
    """ Generates a new random trade position with the date, period sequence and volume sequence
    :param date: Date in d/m/y format
    :return: dict with data
    """

    period_list = [random_nan(i.strftime("%H:%M")) for i in pd.date_range("00:00", "23:59", freq="5min").time]
    volume = [random_nan(x) for x in random.sample(range(0, 500), len(period_list))]

    open_trade_position = {"date": date,
                           "time": period_list,
                           "volume": volume,
                           "id": uuid.uuid4().hex
                           }

    return open_trade_position


def get_trades(date: str):
    """
    Generate some random number of open trade positions
    :param date: date in d/m/y format
    :return:
    """

    if not check_if_valid_date(date=date):
        error_msg = "The supplied date {} is invalid.Please supply a date in the format d/m/Y.".format(date)
        logging.error(error_msg)
        raise ValueError(error_msg)

    # a randomly chosen number of open trades
    number_of_open_trades = random.randint(1, 101)
    logging.info("Generated" + str(number_of_open_trades) + " open trades randomly.")

    open_trades_list = []
    # Generate a list of open trade dicts
    for open_trade in range(0, number_of_open_trades):
        open_trades_list.append(generate_new_random_trade_position(date=date))

    return open_trades_list


def extract_values(trades_list: list) -> DataFrame:
    df_schema = StructType([StructField("date", StringType(), True),
                            StructField("time", ArrayType(StringType()), True),
                            StructField("volume", ArrayType(StringType()), True),
                            StructField("id", StringType(), True)])

    df = spark.createDataFrame(data=trades_list, schema=df_schema)

    fdd = df.select("date",
                    F.explode(F.zip_with(F.col("time"), F.col("volume"), lambda x, y: F.concat_ws("#", x, y))).alias(
                        "new_field"), "id")
    new_df = fdd.select("date", F.split(F.col("new_field"), "#").getItem(0).alias("time"),
                        F.split(F.col("new_field"), "#").getItem(1).alias("volume"), "id")

    # new_df.replace(int('NaN'), None).show(n=100)

    # new_df.show(n=100)

    updated_df = new_df.select(F.to_date(F.col("date"), "dd/MM/yyyy").alias("date"),
                               F.hour(F.col("time")).alias("time"),
                               F.col("volume").cast(IntegerType()),
                               F.col("id"))

    to_return = updated_df.groupBy("time").sum("volume").orderBy("time")
    return to_return


if __name__ == '__main__':
    spark = SparkSession.builder.master("local[1]") \
        .appName('python-powerservice') \
        .getOrCreate()
    trades_today = get_trades(date='01/03/2022')

    trades_today_df = extract_values(trades_today)

    dt_obj = datetime.datetime.strptime("01/01/2022", "%d/%m/%Y")
    prev_date_obj = dt_obj - datetime.timedelta(days=1)

    prev_date = prev_date_obj.strftime("%d/%m/%Y")

    trades_yesterday = get_trades(date=prev_date)
    trades_yesterday_df = extract_values(trades_yesterday)

    output_df = trades_yesterday_df.where(F.col("time") >= F.lit("23")).union(trades_today_df.where(F.col("time") < F.lit("23")))

    output_df.show(n=100)


